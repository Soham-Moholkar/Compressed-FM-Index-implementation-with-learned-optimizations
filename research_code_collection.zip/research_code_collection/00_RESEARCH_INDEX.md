# Compressed Search Engine - Research Code Collection

**Project**: FM-Index Based Compressed Text Search Engine  
**Date**: October 28, 2025  
**Purpose**: Research paper reference and academic study

---

## 📚 Overview

This is a curated collection of the core implementation files for a compressed search engine using FM-Index data structures. The project implements advanced text indexing and search capabilities with compression, enabling efficient substring search on large text corpora.

---

## 🏗️ Project Architecture

```
research_code_collection/
├── core/               # Core data structures (Bitvectors, Wavelet Trees, BWT, Suffix Arrays)
├── api/                # High-level FM-Index interface
├── learned/            # Machine learning optimizations (PGM-Index)
├── layout/             # Memory layout optimizations (van Emde Boas)
├── serialization/      # Index persistence (save/load functionality)
├── util/               # Utilities (I/O, timers, bit operations)
├── tools/              # Command-line applications
├── tests/              # Unit tests and validation
├── config.hpp          # Configuration settings
└── CMakeLists.txt      # Build configuration
```

---

## 📖 Documentation Files

| File | Description |
|------|-------------|
| `01_CORE_STRUCTURES.md` | Detailed explanation of bitvectors, wavelet trees, BWT, and suffix arrays |
| `02_API_INTERFACE.md` | FM-Index API and high-level usage |
| `03_LEARNED_STRUCTURES.md` | Machine learning enhanced data structures |
| `04_OPTIMIZATION_TECHNIQUES.md` | Memory layout and performance optimizations |
| `05_TOOLS_AND_UTILITIES.md` | Command-line tools and helper functions |
| `06_TESTING_FRAMEWORK.md` | Test suite and validation strategies |
| `07_BUILD_AND_USAGE.md` | Compilation and usage instructions |
| `08_RESEARCH_CONCEPTS.md` | Theoretical background and algorithmic concepts |

---

## 🎯 Key Features

1. **FM-Index Implementation**: Full-text index supporting pattern search in compressed space
2. **Wavelet Tree**: Rank/select queries on sequences with alphabet compression
3. **Burrows-Wheeler Transform (BWT)**: Text transformation for improved compression
4. **Learned Data Structures**: PGM-Index for optimized rank/select operations
5. **Van Emde Boas Layout**: Cache-friendly memory organization
6. **Serialization**: Persistent index storage for reuse

---

## 🔬 Research Topics Covered

- **Text Compression**: BWT, Run-length encoding
- **Succinct Data Structures**: Space-efficient rank/select support
- **Pattern Matching**: Backward search algorithm
- **Machine Learning in Data Structures**: Learned index structures
- **Cache Optimization**: Memory layout techniques
- **Suffix Arrays**: Space-efficient construction algorithms (SAIS)

---

## 📝 Citation Recommendation

When citing this work in your research paper:
- Reference the FM-Index algorithm (Ferragina & Manzini, 2000)
- Mention Wavelet Trees and rank/select operations
- Include BWT (Burrows-Wheeler Transform, 1994)
- Cite learned index structures if discussing the PGM integration
- Reference SAIS algorithm for suffix array construction

---

## 🚀 Quick Start for Researchers

1. **Read**: Start with `08_RESEARCH_CONCEPTS.md` for theoretical background
2. **Explore**: Review `01_CORE_STRUCTURES.md` for implementation details
3. **Analyze**: Study `core/fm_index.cpp` for the main algorithm
4. **Experiment**: Look at `tests/` for usage examples
5. **Build**: Follow `07_BUILD_AND_USAGE.md` to compile and test

---

## 📊 Performance Characteristics

- **Index Construction**: O(n) time, O(n log σ) bits space
- **Search Query**: O(m log σ) time (m = pattern length, σ = alphabet size)
- **Space Usage**: Typically 0.5-2× compressed text size
- **Cache Performance**: Improved with VEB layout

---

## 🔧 Technical Stack

- **Language**: C++17
- **Build System**: CMake
- **Dependencies**: Standard library (no external dependencies)
- **Platform**: Cross-platform (Windows/Linux/macOS)

---

## 📫 For Research Paper Use

This collection is organized to help you:
- Understand implementation details for technical writing
- Extract code snippets for explanations
- Analyze algorithmic complexity
- Benchmark and compare approaches
- Validate theoretical concepts with practical implementation

---

**Note**: All files are copies from the original project. Refer to individual documentation files for detailed explanations of each component.
